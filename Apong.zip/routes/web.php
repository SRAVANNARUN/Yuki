<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {

    $random = mt_rand(1, 6);

    /*
    //============5-1 and 2-6
        if(request()->random==2){
            $random=6;
        }elseif (request()->random==5){
            $random=1;
        }elseif (request()->random==1){
            $random=mt_rand(1,5);
        }elseif (request()->random==6){
            $random=mt_rand(2,5);
        }
    //============end 5-1 and 2-6
*/
    //============4-1 and 3-6
    /*
        if(request()->random==3){
            $random=6;
        }elseif (request()->random==4){
            $random=1;
        }elseif (request()->random==1){
            $random=mt_rand(1,5);
        }elseif (request()->random==6){
            $random=mt_rand(2,5);
        }

    */
    //============end 4-1 and 3-6

    //not to change
    $result = 'h' . $random . '.png';
    $info = 'ចេញលេខ ' . $random;

    return view('welcome')->with('result', $result)->with('info', $info)->with('random', $random);
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/about', function () {
    return view('about');
});
