@extends('layouts.app')

@section('content')
    <div class="container">

        <div class="alert alert-success" style="font-size: 19px">
            <strong>កម្មវិធី​អាប៉ោង</strong>​​នេះ​ជា​កម្មវិធី​កម្សាន្ត​មួយ​ដែល​ផ្ដល់​នូវ​លទ្ធផល​ចៃដន្យ​ពី​លេខ​ ១ ដល់ ៦ ។ ដូច្នេះ​វា​ផ្ដល់​នូវ​ភាព​យុត្តិធម៌​សម្រាប់​អ្នក​លេង​ មិន​ថា​មេ ឬ​អ្នក​ចាក់​ឡើយ ។ សូម​អរគុណ សូម​សំណាងល្អ ។
        </div>
    </div>
@endsection
